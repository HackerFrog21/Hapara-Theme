# Hapara-Theme
Customize your Hapara Workspace with varieties of diffrent colors

---
Hapara Theme is a Chrome extension that allows you to customize the theme of Hapara Workspace--which 
is a commonly used site, where teachers post homeworks and projects virtually.

##### This extension is still in the early stages of developement, and therefor you may experience some lag and/or delay.


### How do you install this extension if your school board blocks it?

One way to solve this is by signing-in to your personal account and installing this extension. Once completed, add an account to your personal account.
Now, go to Hapara Workspace and sign-in through your school account. Hapara currently has a glitch, where you might have to sign-in multiple times.

This should solve the problem and as a bonus, teachers can't see your screen since you are still in your personal account. :)
